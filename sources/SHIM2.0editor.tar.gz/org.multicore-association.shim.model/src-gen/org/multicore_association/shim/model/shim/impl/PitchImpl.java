/**
 */
package org.multicore_association.shim.model.shim.impl;

import org.eclipse.emf.ecore.EClass;

import org.multicore_association.shim.model.shim.Pitch;
import org.multicore_association.shim.model.shim.ShimPackage;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Pitch</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class PitchImpl extends AbstractPerformanceImpl implements Pitch {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected PitchImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return ShimPackage.Literals.PITCH;
	}

} //PitchImpl
