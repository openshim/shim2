/**
 */
package org.multicore_association.shim.model.shim;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Interrupt Communication</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.multicore_association.shim.model.shim.ShimPackage#getInterruptCommunication()
 * @model extendedMetaData="name='InterruptCommunication' kind='elementOnly'"
 * @generated
 */
public interface InterruptCommunication extends AbstractCommunication {
} // InterruptCommunication
