/**
 */
package org.multicore_association.shim.model.shim;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Latency</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.multicore_association.shim.model.shim.ShimPackage#getLatency()
 * @model extendedMetaData="name='Latency' kind='empty'"
 * @generated
 */
public interface Latency extends AbstractPerformance {
} // Latency
