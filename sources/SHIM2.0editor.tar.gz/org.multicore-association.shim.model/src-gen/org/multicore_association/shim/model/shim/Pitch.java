/**
 */
package org.multicore_association.shim.model.shim;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Pitch</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.multicore_association.shim.model.shim.ShimPackage#getPitch()
 * @model extendedMetaData="name='Pitch' kind='empty'"
 * @generated
 */
public interface Pitch extends AbstractPerformance {
} // Pitch
