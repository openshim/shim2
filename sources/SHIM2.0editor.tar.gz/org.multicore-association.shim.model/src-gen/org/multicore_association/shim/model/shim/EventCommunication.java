/**
 */
package org.multicore_association.shim.model.shim;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Event Communication</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.multicore_association.shim.model.shim.ShimPackage#getEventCommunication()
 * @model extendedMetaData="name='EventCommunication' kind='elementOnly'"
 * @generated
 */
public interface EventCommunication extends AbstractCommunication {
} // EventCommunication
