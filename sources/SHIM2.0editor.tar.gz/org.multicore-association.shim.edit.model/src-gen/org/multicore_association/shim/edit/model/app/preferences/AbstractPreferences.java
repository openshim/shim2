/**
 */
package org.multicore_association.shim.edit.model.app.preferences;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Abstract Preferences</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.multicore_association.shim.edit.model.app.preferences.PreferencesPackage#getAbstractPreferences()
 * @model abstract="true"
 *        extendedMetaData="name='AbstractPreferences' kind='elementOnly'"
 * @generated
 */
public interface AbstractPreferences extends EObject {
} // AbstractPreferences
