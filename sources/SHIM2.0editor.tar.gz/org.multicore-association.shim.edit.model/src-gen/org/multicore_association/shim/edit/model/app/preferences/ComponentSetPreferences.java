/**
 */
package org.multicore_association.shim.edit.model.app.preferences;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Component Set Preferences</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.multicore_association.shim.edit.model.app.preferences.PreferencesPackage#getComponentSetPreferences()
 * @model extendedMetaData="name='ComponentSetPreferences' kind='elementOnly'"
 * @generated
 */
public interface ComponentSetPreferences extends AbstractComponentPreferences {
} // ComponentSetPreferences
