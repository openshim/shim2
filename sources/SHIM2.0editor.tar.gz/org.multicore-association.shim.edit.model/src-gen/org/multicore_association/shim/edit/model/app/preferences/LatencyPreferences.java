/**
 */
package org.multicore_association.shim.edit.model.app.preferences;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Latency Preferences</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.multicore_association.shim.edit.model.app.preferences.PreferencesPackage#getLatencyPreferences()
 * @model extendedMetaData="name='LatencyPreferences' kind='elementOnly'"
 * @generated
 */
public interface LatencyPreferences extends AbstractPerformancePreferences {
} // LatencyPreferences
