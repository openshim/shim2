/**
 */
package org.multicore_association.shim.edit.model.app.preferences;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Pitch Preferences</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.multicore_association.shim.edit.model.app.preferences.PreferencesPackage#getPitchPreferences()
 * @model extendedMetaData="name='PitchPreferences' kind='elementOnly'"
 * @generated
 */
public interface PitchPreferences extends AbstractPerformancePreferences {
} // PitchPreferences
