/**
 */
package org.multicore_association.shim10.model.shim10.impl;

import org.eclipse.emf.ecore.EClass;
import org.multicore_association.shim10.model.shim10.Latency;
import org.multicore_association.shim10.model.shim10.ShimPackage;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Latency</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class LatencyImpl extends AbstractPerformanceImpl implements Latency {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected LatencyImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return ShimPackage.Literals.LATENCY;
	}

} //LatencyImpl
