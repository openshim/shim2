/**
 */
package org.multicore_association.shim10.model.shim10.impl;

import org.eclipse.emf.ecore.EClass;
import org.multicore_association.shim10.model.shim10.InterruptCommunication;
import org.multicore_association.shim10.model.shim10.ShimPackage;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Interrupt Communication</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class InterruptCommunicationImpl extends AbstractCommunicationImpl implements InterruptCommunication {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected InterruptCommunicationImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return ShimPackage.Literals.INTERRUPT_COMMUNICATION;
	}

} //InterruptCommunicationImpl
