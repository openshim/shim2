/**
 */
package org.multicore_association.shim10.model.shim10;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Event Communication</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.multicore_association.shim10.model.shim10.ShimPackage#getEventCommunication()
 * @model extendedMetaData="name='EventCommunication' kind='elementOnly'"
 * @generated
 */
public interface EventCommunication extends AbstractCommunication {
} // EventCommunication
