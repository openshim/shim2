/**
 */
package org.multicore_association.shim10.model.shim10.impl;

import org.eclipse.emf.ecore.EClass;
import org.multicore_association.shim10.model.shim10.EventCommunication;
import org.multicore_association.shim10.model.shim10.ShimPackage;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Event Communication</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class EventCommunicationImpl extends AbstractCommunicationImpl implements EventCommunication {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected EventCommunicationImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return ShimPackage.Literals.EVENT_COMMUNICATION;
	}

} //EventCommunicationImpl
